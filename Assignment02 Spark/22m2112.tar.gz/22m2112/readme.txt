
<entities.txt > and < history-english.json > input files

< Solution 22m2112 OMKAR KADAM : PySpark Beginner - Colaboratory.pdf  > file contains entire code of all four questions and its their outputs right after one another.

< PySpark_Beginner.ipynb > is python notebook which you can run on jupiter notebook or google colab. You only have place the input files entities.txt and history-english.json files in the same directory and cross check the paths of these files given to read their data at the the start of code. Run each cell one after another.

OR

https://drive.google.com/drive/folders/1HuLlRZ9HKFAUWZAtUvXlANI9pHL5qvJN?usp=sharing

you can click on above link (it will open in colab directly) and by uploading the two input files (by clicking on upload to session storage) you can run the code.


< question1-output.csv > is and output csv file of Question 1

< question2-output.csv > is and output csv file of Question 2

< question3-output.csv > is and output csv file of Question 3

< question4-output.csv > is and output csv file of Question 4

Name: Omkar Kadam 
Roll No: 22m2112
MS by Research CSE 
IIT Bombay
